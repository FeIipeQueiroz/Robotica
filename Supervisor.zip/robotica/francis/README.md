# FRANCIS SUPERVIOR SYSTEM

Este trabalho é fruto da disciplina Fundamentos da Róbotica, isto é um protótipo

## Requisitos

    * Python 3.7 ou inferior 
    * Ambiente Linux

## Conexão Bluetooth com Bleutoothctl

